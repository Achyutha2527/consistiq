import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, BellOff, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getNotifSettings, saveNotifSettings } from '@/lib/notifications';
import { requestNotificationPermission, onForegroundMessage, initFirebase } from '@/lib/firebase';
import { toast } from 'sonner';

export default function NotificationBanner() {
  const [show, setShow] = useState(false);
  const [permState, setPermState] = useState<NotificationPermission | 'unsupported'>('default');

  useEffect(() => {
    if (!('Notification' in window)) {
      setPermState('unsupported');
      return;
    }
    setPermState(Notification.permission);

    if (Notification.permission === 'default') {
      const dismissed = localStorage.getItem('consistiq_notif_dismissed');
      if (!dismissed || Date.now() - parseInt(dismissed) > 3 * 24 * 60 * 60 * 1000) {
        const timer = setTimeout(() => setShow(true), 5000);
        return () => clearTimeout(timer);
      }
    }

    // Setup foreground message handler
    if (Notification.permission === 'granted') {
      initFirebase();
      onForegroundMessage((payload: any) => {
        const { title, body } = payload.notification || {};
        if (title) toast(title, { description: body });
      });
    }
  }, []);

  const handleEnable = async () => {
    const token = await requestNotificationPermission();
    if (token) {
      saveNotifSettings({ enabled: true, fcmToken: token });
      setPermState('granted');
      toast.success('Notifications enabled 🔔 Stay consistent!');
    } else if (Notification.permission === 'denied') {
      setPermState('denied');
      toast.error('Enable notifications in browser settings');
    }
    setShow(false);
  };

  const handleDismiss = () => {
    setShow(false);
    localStorage.setItem('consistiq_notif_dismissed', Date.now().toString());
  };

  if (!show || permState === 'granted' || permState === 'unsupported') return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: -60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -60, opacity: 0 }}
        className="fixed top-2 left-3 right-3 z-[60] max-w-lg mx-auto"
      >
        <div className="glass-strong rounded-2xl p-4 shadow-2xl border border-accent/20">
          <button
            onClick={handleDismiss}
            className="absolute top-3 right-3 text-muted-foreground hover:text-foreground"
          >
            <X size={16} />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
              <Bell size={20} className="text-accent" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">Enable Notifications</p>
              <p className="text-xs text-muted-foreground">Get reminders to stay on track 🔔</p>
            </div>
          </div>
          {permState === 'denied' ? (
            <p className="text-xs text-destructive mt-3 text-center">
              Notifications blocked. Enable in browser settings.
            </p>
          ) : (
            <Button onClick={handleEnable} className="w-full mt-3 h-9 rounded-xl bg-accent text-accent-foreground text-sm font-semibold">
              <Bell size={14} className="mr-2" /> Enable Notifications
            </Button>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
