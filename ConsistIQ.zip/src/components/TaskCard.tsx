import { Task } from '@/types';
import { formatTime, isAfterEndTime, getISTNow } from '@/lib/time';
import { motion } from 'framer-motion';
import { Play, Check, X, Lock, Clock } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface Props {
  task: Task;
  onStart: (id: string) => void;
  onComplete: (id: string) => void;
  onMiss: (id: string, reason: string) => void;
}

const statusColors: Record<string, string> = {
  'upcoming': 'border-l-accent',
  'in-progress': 'border-l-primary',
  'pending': 'border-l-yellow-500',
  'completed': 'border-l-success',
  'missed': 'border-l-destructive',
};

const statusLabels: Record<string, string> = {
  'upcoming': 'Upcoming',
  'in-progress': 'In Progress',
  'pending': 'Pending',
  'completed': 'Completed ✅',
  'missed': 'Missed ❌',
};

export default function TaskCard({ task, onStart, onComplete, onMiss }: Props) {
  const [reason, setReason] = useState('');
  const [showReason, setShowReason] = useState(false);
  const ended = isAfterEndTime(task.date, task.endTime);
  const locked = task.status === 'completed' || task.status === 'missed';

  // Determine if currently in time range
  const now = getISTNow();
  const [sh, sm] = task.startTime.split(':').map(Number);
  const start = new Date(task.date);
  start.setHours(sh, sm, 0, 0);
  const isActive = now >= start && !ended;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`glass rounded-xl p-4 border-l-4 ${statusColors[task.status] || 'border-l-muted'}`}
    >
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-semibold text-foreground">{task.subject}</h3>
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            <Clock size={12} />
            {formatTime(task.startTime)} – {formatTime(task.endTime)}
          </p>
        </div>
        <span className={`text-xs px-2 py-1 rounded-full ${
          task.status === 'completed' ? 'bg-success/20 text-success' :
          task.status === 'missed' ? 'bg-destructive/20 text-destructive' :
          'bg-secondary text-muted-foreground'
        }`}>
          {statusLabels[task.status]}
        </span>
      </div>

      {locked && task.reason && (
        <p className="text-xs text-muted-foreground mt-1 italic">Reason: {task.reason}</p>
      )}

      {!locked && (
        <div className="flex gap-2 mt-3">
          {!ended && isActive && task.status !== 'completed' && (
            <Button size="sm" className="gradient-primary text-primary-foreground flex-1 gap-1" onClick={() => onStart(task.id)}>
              <Play size={14} /> Focus
            </Button>
          )}
          {!ended && (
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Lock size={12} /> Available after scheduled time
            </p>
          )}
          {ended && (
            <>
              <Button size="sm" className="bg-success text-success-foreground flex-1 gap-1" onClick={() => onComplete(task.id)}>
                <Check size={14} /> Done
              </Button>
              <Button size="sm" variant="destructive" className="flex-1 gap-1" onClick={() => setShowReason(true)}>
                <X size={14} /> Missed
              </Button>
            </>
          )}
        </div>
      )}

      {showReason && (
        <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} className="mt-3 overflow-hidden">
          <textarea
            value={reason}
            onChange={e => setReason(e.target.value)}
            placeholder="Why did you miss this task? (Required)"
            className="w-full bg-secondary/50 border border-border rounded-lg p-2 text-sm text-foreground resize-none"
            rows={2}
          />
          <Button
            size="sm"
            variant="destructive"
            className="mt-2 w-full"
            disabled={!reason.trim()}
            onClick={() => { onMiss(task.id, reason); setShowReason(false); }}
          >
            Confirm Missed
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
}
