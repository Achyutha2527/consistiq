import { NavLink, useLocation } from 'react-router-dom';
import { Home, ListTodo, Clock, Trophy, User } from 'lucide-react';
import { motion } from 'framer-motion';

const tabs = [
  { path: '/dashboard', icon: Home, label: 'Home' },
  { path: '/tasks', icon: ListTodo, label: 'Tasks' },
  { path: '/plan', icon: Clock, label: 'Plan' },
  { path: '/leaderboard', icon: Trophy, label: 'Rank' },
  { path: '/profile', icon: User, label: 'Profile' },
];

export default function BottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass-strong border-t border-white/10">
      <div className="flex justify-around items-center h-16 max-w-lg mx-auto px-2">
        {tabs.map(({ path, icon: Icon, label }) => {
          const active = location.pathname === path;
          return (
            <NavLink key={path} to={path} className="flex flex-col items-center gap-0.5 py-1 px-3 relative">
              {active && (
                <motion.div
                  layoutId="bottomTab"
                  className="absolute -top-0.5 w-8 h-0.5 gradient-primary rounded-full"
                />
              )}
              <Icon size={20} className={active ? 'text-primary' : 'text-muted-foreground'} />
              <span className={`text-[10px] ${active ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>
                {label}
              </span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
