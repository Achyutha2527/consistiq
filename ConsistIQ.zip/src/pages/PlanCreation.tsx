import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Task } from '@/types';
import { generateId, addTaskToDay } from '@/lib/storage';
import { getISTDate } from '@/lib/time';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Sparkles, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PlanCreation() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'manual' | 'ai'>('manual');
  const [date, setDate] = useState(getISTDate());
  const [slots, setSlots] = useState<{ start: string; end: string; subject: string }[]>([
    { start: '09:00', end: '10:00', subject: '' },
  ]);

  // AI mode
  const [goals, setGoals] = useState('');
  const [timeRange, setTimeRange] = useState({ start: '09:00', end: '17:00' });
  const [taskCount, setTaskCount] = useState(4);
  const [aiLoading, setAiLoading] = useState(false);

  if (!user) return null;

  const addSlot = () => {
    const last = slots[slots.length - 1];
    setSlots([...slots, { start: last.end, end: '', subject: '' }]);
  };

  const updateSlot = (i: number, field: string, value: string) => {
    const s = [...slots];
    (s[i] as any)[field] = value;
    setSlots(s);
  };

  const removeSlot = (i: number) => {
    if (slots.length > 1) setSlots(slots.filter((_, idx) => idx !== i));
  };

  const submitManual = () => {
    let u = { ...user };
    for (const slot of slots) {
      if (!slot.subject.trim() || !slot.start || !slot.end) continue;
      const task: Task = {
        id: generateId(),
        date,
        startTime: slot.start,
        endTime: slot.end,
        subject: slot.subject,
        status: 'upcoming',
        points: 0,
      };
      u = addTaskToDay(u, task);
    }
    updateUser(u);
    navigate('/tasks');
  };

  const generateAI = async () => {
    setAiLoading(true);
    // Simple AI-like generation (client-side for now since no backend)
    const subjects = goals.split(',').map(s => s.trim()).filter(Boolean);
    if (subjects.length === 0) { setAiLoading(false); return; }

    const [startH] = timeRange.start.split(':').map(Number);
    const [endH] = timeRange.end.split(':').map(Number);
    const totalHours = endH - startH;
    const slotDuration = Math.max(1, Math.floor(totalHours / taskCount));

    const generated: typeof slots = [];
    let currentH = startH;
    for (let i = 0; i < taskCount && currentH < endH; i++) {
      const endSlotH = Math.min(currentH + slotDuration, endH);
      generated.push({
        start: `${String(currentH).padStart(2, '0')}:00`,
        end: `${String(endSlotH).padStart(2, '0')}:00`,
        subject: subjects[i % subjects.length],
      });
      currentH = endSlotH;
    }
    setSlots(generated);
    setMode('manual'); // Switch to manual to allow editing
    setAiLoading(false);
  };

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-5">
        <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold text-foreground">
          Create Plan
        </motion.h1>

        {/* Mode Toggle */}
        <div className="flex bg-secondary/50 rounded-xl p-1">
          {[
            { key: 'manual', label: 'Manual', icon: <Plus size={14} /> },
            { key: 'ai', label: 'AI Generate', icon: <Sparkles size={14} /> },
          ].map(({ key, label, icon }) => (
            <button
              key={key}
              onClick={() => setMode(key as any)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-1.5 transition-all ${
                mode === key ? 'gradient-primary text-primary-foreground' : 'text-muted-foreground'
              }`}
            >
              {icon} {label}
            </button>
          ))}
        </div>

        {mode === 'ai' ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <div className="glass rounded-xl p-4 space-y-3">
              <label className="text-sm text-muted-foreground">Study Goals (comma separated)</label>
              <Input
                value={goals}
                onChange={e => setGoals(e.target.value)}
                placeholder="Math, Physics, Chemistry"
                className="bg-secondary/50 border-border rounded-xl"
              />
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground">From</label>
                  <Input type="time" value={timeRange.start} onChange={e => setTimeRange({ ...timeRange, start: e.target.value })} className="bg-secondary/50 border-border rounded-xl" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">To</label>
                  <Input type="time" value={timeRange.end} onChange={e => setTimeRange({ ...timeRange, end: e.target.value })} className="bg-secondary/50 border-border rounded-xl" />
                </div>
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Number of tasks</label>
                <Input type="number" value={taskCount} onChange={e => setTaskCount(Number(e.target.value))} min={1} max={12} className="bg-secondary/50 border-border rounded-xl" />
              </div>
            </div>
            <Button onClick={generateAI} disabled={aiLoading || !goals.trim()} className="w-full h-12 gradient-primary rounded-xl text-base font-semibold">
              {aiLoading ? 'Generating...' : 'Generate Plan ✨'}
            </Button>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <div className="glass rounded-xl p-4">
              <label className="text-sm text-muted-foreground">Date</label>
              <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="bg-secondary/50 border-border rounded-xl mt-1" />
            </div>

            <div className="space-y-3">
              {slots.map((slot, i) => (
                <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} className="glass rounded-xl p-4 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground font-medium">Task {i + 1}</span>
                    {slots.length > 1 && (
                      <button onClick={() => removeSlot(i)} className="text-destructive text-xs">Remove</button>
                    )}
                  </div>
                  <Input
                    placeholder="Subject / Task"
                    value={slot.subject}
                    onChange={e => updateSlot(i, 'subject', e.target.value)}
                    className="bg-secondary/50 border-border rounded-xl"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <Input type="time" value={slot.start} onChange={e => updateSlot(i, 'start', e.target.value)} className="bg-secondary/50 border-border rounded-xl" />
                    <Input type="time" value={slot.end} onChange={e => updateSlot(i, 'end', e.target.value)} className="bg-secondary/50 border-border rounded-xl" />
                  </div>
                </motion.div>
              ))}
            </div>

            <Button onClick={addSlot} variant="outline" className="w-full border-dashed border-border text-muted-foreground rounded-xl">
              <Plus size={16} /> Continue (Add Slot)
            </Button>

            <Button onClick={submitManual} className="w-full h-12 gradient-primary rounded-xl text-base font-semibold flex gap-2">
              Submit Plan <ArrowRight size={18} />
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
