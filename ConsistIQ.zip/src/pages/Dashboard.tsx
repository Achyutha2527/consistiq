import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { getTasksForDate } from '@/lib/storage';
import { getISTDate } from '@/lib/time';
import { motion } from 'framer-motion';
import { Plus, ListTodo, History, Flame, Star, Medal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

const badgeEmoji: Record<string, string> = { beginner: '🌱', consistent: '🔥', unstoppable: '💎' };

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  if (!user) return null;

  const today = getISTDate();
  const tasks = getTasksForDate(user, today);
  const completed = tasks.filter(t => t.status === 'completed').length;
  const pct = tasks.length > 0 ? Math.round((completed / tasks.length) * 100) : 0;

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-6">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
          <p className="text-muted-foreground text-sm">{greeting}</p>
          <h1 className="text-2xl font-bold text-foreground">{user.username} 👋</h1>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-3"
        >
          {[
            { icon: <Flame size={20} className="text-orange-400" />, label: 'Streak', value: `${user.currentStreak}🔥` },
            { icon: <Star size={20} className="text-yellow-400" />, label: 'Points', value: user.points },
            { icon: <Medal size={20} className="text-purple-400" />, label: 'Badge', value: badgeEmoji[user.badge] },
          ].map((s, i) => (
            <div key={i} className="glass rounded-xl p-3 text-center">
              <div className="flex justify-center mb-1">{s.icon}</div>
              <p className="text-lg font-bold text-foreground">{s.value}</p>
              <p className="text-[10px] text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Today Progress */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-xl p-4"
        >
          <div className="flex justify-between items-center mb-2">
            <h2 className="font-semibold text-foreground">Today's Progress</h2>
            <span className="text-sm text-muted-foreground">{completed}/{tasks.length} tasks</span>
          </div>
          <Progress value={pct} className="h-2 bg-secondary" />
          <p className="text-xs text-muted-foreground mt-1">{pct}% complete</p>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-3"
        >
          <h2 className="font-semibold text-foreground">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            <Button onClick={() => navigate('/plan')} className="h-14 glass hover:bg-primary/20 text-foreground rounded-xl flex gap-2">
              <Plus size={18} /> Create Plan
            </Button>
            <Button onClick={() => navigate('/tasks')} className="h-14 glass hover:bg-primary/20 text-foreground rounded-xl flex gap-2">
              <ListTodo size={18} /> View Tasks
            </Button>
            <Button onClick={() => navigate('/history')} className="h-14 glass hover:bg-primary/20 text-foreground rounded-xl flex gap-2 col-span-2">
              <History size={18} /> View History
            </Button>
          </div>
        </motion.div>

        {/* Today's Tasks Preview */}
        {tasks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="font-semibold text-foreground mb-3">Upcoming Tasks</h2>
            <div className="space-y-2">
              {tasks.slice(0, 3).map(t => (
                <div key={t.id} className="glass rounded-xl p-3 flex justify-between items-center">
                  <div>
                    <p className="text-sm font-medium text-foreground">{t.subject}</p>
                    <p className="text-xs text-muted-foreground">{t.startTime} – {t.endTime}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    t.status === 'completed' ? 'bg-success/20 text-success' :
                    t.status === 'missed' ? 'bg-destructive/20 text-destructive' :
                    'bg-secondary text-muted-foreground'
                  }`}>{t.status}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
