import { getAllUsers } from '@/lib/storage';
import { useAuth } from '@/contexts/AuthContext';
import { LeaderboardEntry } from '@/types';
import { motion } from 'framer-motion';
import { Trophy } from 'lucide-react';

const SIMULATED: LeaderboardEntry[] = [
  { username: 'Arjun_Pro', points: 450, streak: 15, completionPct: 88, isSimulated: true },
  { username: 'StudyQueen', points: 380, streak: 12, completionPct: 82, isSimulated: true },
  { username: 'DisciplinedDev', points: 320, streak: 10, completionPct: 78, isSimulated: true },
  { username: 'FocusMaster', points: 290, streak: 9, completionPct: 75, isSimulated: true },
  { username: 'ConsistentKid', points: 250, streak: 7, completionPct: 70, isSimulated: true },
];

function getAvatar(name: string) {
  const colors = ['bg-purple-500', 'bg-blue-500', 'bg-green-500', 'bg-orange-500', 'bg-pink-500', 'bg-cyan-500'];
  const idx = name.charCodeAt(0) % colors.length;
  return { color: colors[idx], letter: name[0].toUpperCase() };
}

export default function Leaderboard() {
  const { user } = useAuth();
  const users = getAllUsers();

  const realEntries: LeaderboardEntry[] = users
    .filter(u => u.username && u.username.trim())
    .map(u => {
      const totalTasks = u.history.reduce((s, d) => s + d.tasks.length, 0);
      const completedTasks = u.history.reduce((s, d) => s + d.tasks.filter(t => t.status === 'completed').length, 0);
      return {
        username: u.username,
        points: u.points,
        streak: u.currentStreak,
        completionPct: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
      };
    });

  // Fill with simulated if needed
  const needed = Math.max(0, 5 - realEntries.length);
  const entries = [...realEntries, ...SIMULATED.slice(0, needed)]
    .sort((a, b) => b.points - a.points || b.streak - a.streak || b.completionPct - a.completionPct);

  const medals = ['🥇', '🥈', '🥉'];

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-5">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2">
          <Trophy className="text-yellow-400" size={24} />
          <h1 className="text-2xl font-bold text-foreground">Leaderboard</h1>
        </motion.div>

        {/* Top 3 */}
        <div className="flex justify-center gap-4 py-4">
          {entries.slice(0, 3).map((e, i) => {
            const order = [1, 0, 2]; // 2nd, 1st, 3rd
            const idx = order[i];
            const entry = entries[idx];
            if (!entry) return null;
            const av = getAvatar(entry.username);
            return (
              <motion.div
                key={entry.username}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`text-center ${idx === 0 ? 'scale-110' : ''}`}
              >
                <div className={`w-14 h-14 rounded-full ${av.color} flex items-center justify-center text-xl font-bold text-primary-foreground mx-auto mb-1 ${idx === 0 ? 'ring-2 ring-yellow-400 animate-pulse-glow' : ''}`}>
                  {av.letter}
                </div>
                <span className="text-lg">{medals[idx]}</span>
                <p className="text-xs font-semibold text-foreground truncate max-w-[80px]">{entry.username}</p>
                <p className="text-[10px] text-muted-foreground">{entry.points} pts</p>
              </motion.div>
            );
          })}
        </div>

        {/* Full List */}
        <div className="space-y-2">
          {entries.map((entry, i) => {
            const av = getAvatar(entry.username);
            const isMe = user?.username === entry.username;
            return (
              <motion.div
                key={entry.username + i}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`glass rounded-xl p-3 flex items-center gap-3 ${isMe ? 'ring-1 ring-primary' : ''}`}
              >
                <span className="text-sm font-bold text-muted-foreground w-6 text-center">#{i + 1}</span>
                <div className={`w-9 h-9 rounded-full ${av.color} flex items-center justify-center text-sm font-bold text-primary-foreground shrink-0`}>
                  {av.letter}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">
                    {entry.username} {isMe && <span className="text-xs text-primary">(You)</span>}
                  </p>
                  <p className="text-[10px] text-muted-foreground">{entry.completionPct}% completion</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-foreground">{entry.points}</p>
                  <p className="text-[10px] text-muted-foreground">{entry.streak}🔥</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
