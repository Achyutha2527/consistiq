import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getLoginQuote } from '@/lib/quotes';
import MotivationOverlay from '@/components/MotivationOverlay';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Zap } from 'lucide-react';

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showMotivation, setShowMotivation] = useState(false);
  const [quote, setQuote] = useState('');
  const { login, signup } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!username.trim() || !password.trim()) { setError('Fill all fields'); return; }
    if (password.length < 4) { setError('Password must be 4+ characters'); return; }

    if (isLogin) {
      const ok = await login(username.trim(), password);
      if (!ok) { setError('Invalid credentials'); return; }
    } else {
      const res = await signup(username.trim(), password);
      if (!res.success) { setError(res.error || 'Signup failed'); return; }
    }
    setQuote(getLoginQuote());
    setShowMotivation(true);
  }, [username, password, isLogin, login, signup]);

  if (showMotivation) {
    return <MotivationOverlay quote={quote} onDone={() => navigate('/dashboard')} />;
  }

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-4"
          >
            <Zap size={32} className="text-primary-foreground" />
          </motion.div>
          <h1 className="text-3xl font-bold text-gradient">ConsistIQ</h1>
          <p className="text-muted-foreground text-sm mt-1">AI-Powered Study Discipline</p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex mb-6 bg-secondary/50 rounded-xl p-1">
            {['Login', 'Sign Up'].map((tab, i) => (
              <button
                key={tab}
                onClick={() => { setIsLogin(i === 0); setError(''); }}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
                  (i === 0 ? isLogin : !isLogin)
                    ? 'gradient-primary text-primary-foreground'
                    : 'text-muted-foreground'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              placeholder="Username"
              value={username}
              onChange={e => setUsername(e.target.value)}
              className="bg-secondary/50 border-border h-12 rounded-xl"
            />
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="bg-secondary/50 border-border h-12 rounded-xl"
            />
            {error && <p className="text-destructive text-xs text-center">{error}</p>}
            <Button type="submit" className="w-full h-12 gradient-primary text-primary-foreground rounded-xl text-base font-semibold">
              {isLogin ? 'Login' : 'Create Account'}
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
