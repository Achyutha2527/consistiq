import { useAuth } from '@/contexts/AuthContext';
import { deleteDayFromUser } from '@/lib/storage';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';

export default function HistoryPage() {
  const { user, updateUser } = useAuth();
  const [filter, setFilter] = useState<'daily' | 'weekly'>('daily');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [confirmText, setConfirmText] = useState('');

  if (!user) return null;

  const sorted = [...user.history].sort((a, b) => b.date.localeCompare(a.date));

  const handleDelete = () => {
    if (confirmText !== 'DELETE' || !deleteTarget) return;
    const updated = deleteDayFromUser({ ...user }, deleteTarget);
    updateUser(updated);
    setDeleteTarget(null);
    setConfirmText('');
  };

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-4">
        <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold text-foreground">
          History
        </motion.h1>

        <div className="flex bg-secondary/50 rounded-xl p-1">
          {['daily', 'weekly'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f as any)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize ${filter === f ? 'gradient-primary text-primary-foreground' : 'text-muted-foreground'}`}
            >
              {f}
            </button>
          ))}
        </div>

        {sorted.length === 0 ? (
          <div className="glass rounded-xl p-8 text-center">
            <p className="text-4xl mb-3">📊</p>
            <p className="text-muted-foreground">No history yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {sorted.map(day => (
              <motion.div key={day.date} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpanded(expanded === day.date ? null : day.date)}
                  className="w-full p-4 flex justify-between items-center"
                >
                  <div className="text-left">
                    <p className="font-semibold text-foreground">{day.date}</p>
                    <p className="text-xs text-muted-foreground">{day.tasks.length} tasks · {day.completionPercentage}% · {day.points} pts</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={e => { e.stopPropagation(); setDeleteTarget(day.date); }} className="text-destructive/60 hover:text-destructive p-1">
                      <Trash2 size={16} />
                    </button>
                    {expanded === day.date ? <ChevronUp size={16} className="text-muted-foreground" /> : <ChevronDown size={16} className="text-muted-foreground" />}
                  </div>
                </button>
                {expanded === day.date && (
                  <div className="px-4 pb-4 space-y-2">
                    {day.tasks.map(t => (
                      <div key={t.id} className="bg-secondary/30 rounded-lg p-3">
                        <div className="flex justify-between">
                          <span className="text-sm font-medium text-foreground">{t.subject}</span>
                          <span className={`text-xs ${t.status === 'completed' ? 'text-success' : t.status === 'missed' ? 'text-destructive' : 'text-muted-foreground'}`}>
                            {t.status}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">{t.startTime} – {t.endTime}</p>
                        {t.reason && <p className="text-xs text-destructive/80 mt-1 italic">Reason: {t.reason}</p>}
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={!!deleteTarget} onOpenChange={() => { setDeleteTarget(null); setConfirmText(''); }}>
        <DialogContent className="glass-strong border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Delete Day Record</DialogTitle>
            <DialogDescription>Are you sure? This cannot be undone. Type "DELETE" to confirm.</DialogDescription>
          </DialogHeader>
          <Input value={confirmText} onChange={e => setConfirmText(e.target.value)} placeholder='Type "DELETE"' className="bg-secondary/50 border-border" />
          <DialogFooter>
            <Button variant="outline" onClick={() => { setDeleteTarget(null); setConfirmText(''); }}>Cancel</Button>
            <Button variant="destructive" disabled={confirmText !== 'DELETE'} onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
