import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { LogOut, Flame, Star, Medal, Calendar, CheckCircle, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const badgeInfo: Record<string, { label: string; emoji: string; color: string }> = {
  beginner: { label: 'Beginner', emoji: '🌱', color: 'text-green-400' },
  consistent: { label: 'Consistent', emoji: '🔥', color: 'text-orange-400' },
  unstoppable: { label: 'Unstoppable', emoji: '💎', color: 'text-cyan-400' },
};

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  if (!user) return null;

  const totalTasks = user.history.reduce((s, d) => s + d.tasks.length, 0);
  const completedTasks = user.history.reduce((s, d) => s + d.tasks.filter(t => t.status === 'completed').length, 0);
  const badge = badgeInfo[user.badge];

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-5">
        {/* Avatar & Name */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <div className="w-20 h-20 rounded-full gradient-primary flex items-center justify-center text-3xl font-bold text-primary-foreground mx-auto mb-3">
            {user.username[0].toUpperCase()}
          </div>
          <h1 className="text-2xl font-bold text-foreground">{user.username}</h1>
          <p className={`text-sm ${badge.color} font-medium`}>{badge.emoji} {badge.label}</p>
          <p className="text-xs text-muted-foreground mt-1">Joined {new Date(user.createdAt).toLocaleDateString()}</p>
        </motion.div>

        {/* Stats */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 gap-3">
          {[
            { icon: <Star size={18} className="text-yellow-400" />, label: 'Total Points', value: user.points },
            { icon: <Flame size={18} className="text-orange-400" />, label: 'Best Streak', value: `${user.bestStreak} days` },
            { icon: <Calendar size={18} className="text-accent" />, label: 'Total Tasks', value: totalTasks },
            { icon: <CheckCircle size={18} className="text-success" />, label: 'Completed', value: completedTasks },
          ].map((s, i) => (
            <div key={i} className="glass rounded-xl p-4 text-center">
              <div className="flex justify-center mb-2">{s.icon}</div>
              <p className="text-lg font-bold text-foreground">{s.value}</p>
              <p className="text-[10px] text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Actions */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }} className="space-y-3">
          <Button onClick={() => navigate('/history')} variant="outline" className="w-full h-12 glass border-border text-foreground rounded-xl">
            View Full History
          </Button>
          <Button onClick={() => navigate('/friends')} variant="outline" className="w-full h-12 glass border-border text-foreground rounded-xl">
            Friends
          </Button>
          <Button onClick={() => navigate('/settings')} variant="outline" className="w-full h-12 glass border-border text-foreground rounded-xl flex gap-2">
            <Settings size={18} /> Settings
          </Button>
          <Button
            onClick={() => { logout(); navigate('/'); }}
            variant="destructive"
            className="w-full h-12 rounded-xl flex gap-2"
          >
            <LogOut size={18} /> Logout
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
