import { useAuth } from '@/contexts/AuthContext';
import { getTasksForDate, updateTaskInUser } from '@/lib/storage';
import { getISTDate } from '@/lib/time';
import { getSuccessQuote, getMissedQuote } from '@/lib/quotes';
import TaskCard from '@/components/TaskCard';
import MotivationOverlay from '@/components/MotivationOverlay';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ActiveTasks() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [motivation, setMotivation] = useState<{ quote: string } | null>(null);

  if (!user) return null;
  const today = getISTDate();
  const tasks = getTasksForDate(user, today);

  const onStart = (id: string) => navigate(`/focus/${id}`);

  const onComplete = (id: string) => {
    const updated = updateTaskInUser({ ...user }, id, { status: 'completed', points: 10, lockedAt: new Date().toISOString() });
    updateUser(updated);
    setMotivation({ quote: getSuccessQuote() });
  };

  const onMiss = (id: string, reason: string) => {
    const updated = updateTaskInUser({ ...user }, id, { status: 'missed', reason, points: 0, lockedAt: new Date().toISOString() });
    updateUser(updated);
    setMotivation({ quote: getMissedQuote() });
  };

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      {motivation && <MotivationOverlay quote={motivation.quote} onDone={() => setMotivation(null)} />}
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-4">
        <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-2xl font-bold text-foreground">
          Today's Tasks
        </motion.h1>
        <p className="text-sm text-muted-foreground">{today}</p>

        {tasks.length === 0 ? (
          <div className="glass rounded-xl p-8 text-center">
            <p className="text-4xl mb-3">📝</p>
            <p className="text-muted-foreground">No tasks for today</p>
            <button onClick={() => navigate('/plan')} className="text-primary text-sm mt-2 underline">Create a plan</button>
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map(t => (
              <TaskCard key={t.id} task={t} onStart={onStart} onComplete={onComplete} onMiss={onMiss} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
