import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { Bell, BellOff, ArrowLeft, Smartphone } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { getNotifSettings, saveNotifSettings } from '@/lib/notifications';
import { requestNotificationPermission } from '@/lib/firebase';
import { toast } from 'sonner';

export default function SettingsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifEnabled, setNotifEnabled] = useState(true);
  const [permState, setPermState] = useState<string>('default');

  useEffect(() => {
    const settings = getNotifSettings();
    setNotifEnabled(settings.enabled);
    if ('Notification' in window) {
      setPermState(Notification.permission);
    } else {
      setPermState('unsupported');
    }
  }, []);

  const handleToggle = async (enabled: boolean) => {
    if (enabled && permState !== 'granted') {
      const token = await requestNotificationPermission();
      if (token) {
        saveNotifSettings({ enabled: true, fcmToken: token });
        setNotifEnabled(true);
        setPermState('granted');
        toast.success('Notifications enabled 🔔');
      } else {
        toast.error('Permission denied. Enable in browser settings.');
        setPermState(Notification.permission);
        return;
      }
    } else {
      const settings = getNotifSettings();
      saveNotifSettings({ ...settings, enabled });
      setNotifEnabled(enabled);
      toast(enabled ? 'Notifications enabled 🔔' : 'Notifications disabled 🔕');
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-5">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-foreground">
            <ArrowLeft size={20} />
          </Button>
          <h1 className="text-xl font-bold text-foreground">Settings</h1>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="space-y-3">
          {/* Notifications */}
          <div className="glass rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {notifEnabled ? <Bell size={20} className="text-accent" /> : <BellOff size={20} className="text-muted-foreground" />}
                <div>
                  <p className="text-sm font-semibold text-foreground">Push Notifications</p>
                  <p className="text-xs text-muted-foreground">
                    {permState === 'unsupported' ? 'Not supported on this browser' :
                      permState === 'denied' ? 'Blocked — enable in browser settings' :
                        notifEnabled ? 'Reminders and alerts active' : 'Notifications paused'}
                  </p>
                </div>
              </div>
              <Switch
                checked={notifEnabled}
                onCheckedChange={handleToggle}
                disabled={permState === 'unsupported'}
              />
            </div>
          </div>

          {/* App Info */}
          <div className="glass rounded-xl p-4">
            <div className="flex items-center gap-3">
              <Smartphone size={20} className="text-primary" />
              <div>
                <p className="text-sm font-semibold text-foreground">Install App</p>
                <p className="text-xs text-muted-foreground">Add to home screen for the best experience</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
