import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { getUserByUsername, saveUser } from '@/lib/storage';
import { motion } from 'framer-motion';
import { UserPlus, Search, Users, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function FriendsPage() {
  const { user, updateUser } = useAuth();
  const [search, setSearch] = useState('');
  const [msg, setMsg] = useState('');
  const [copied, setCopied] = useState(false);

  if (!user) return null;

  const addFriend = () => {
    if (!search.trim()) return;
    const friend = getUserByUsername(search.trim());
    if (!friend) { setMsg('User not found'); return; }
    if (friend.id === user.id) { setMsg("That's you!"); return; }
    if (user.friends.includes(friend.id)) { setMsg('Already friends'); return; }

    const u = { ...user, friends: [...user.friends, friend.id] };
    updateUser(u);

    // Add back
    if (!friend.friends.includes(user.id)) {
      friend.friends.push(user.id);
      saveUser(friend);
    }
    setMsg(`Added ${friend.username}!`);
    setSearch('');
  };

  const copyCode = () => {
    navigator.clipboard.writeText(user.friendCodes[0] || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const friendUsers = user.friends.map(fid => {
    const all = JSON.parse(localStorage.getItem('consistiq_users') || '[]');
    return all.find((u: any) => u.id === fid);
  }).filter(Boolean);

  return (
    <div className="min-h-screen gradient-bg safe-bottom">
      <div className="p-5 pt-8 max-w-lg mx-auto space-y-5">
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2">
          <Users className="text-accent" size={24} />
          <h1 className="text-2xl font-bold text-foreground">Friends</h1>
        </motion.div>

        {/* Invite Code */}
        <div className="glass rounded-xl p-4">
          <p className="text-xs text-muted-foreground mb-2">Your Invite Code</p>
          <div className="flex gap-2">
            <div className="flex-1 bg-secondary/50 rounded-lg px-3 py-2 text-foreground text-sm font-mono">
              {user.friendCodes[0]}
            </div>
            <Button size="sm" variant="outline" onClick={copyCode} className="rounded-lg">
              {copied ? <Check size={16} /> : <Copy size={16} />}
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="glass rounded-xl p-4">
          <p className="text-xs text-muted-foreground mb-2">Add Friend by Username</p>
          <div className="flex gap-2">
            <Input
              value={search}
              onChange={e => { setSearch(e.target.value); setMsg(''); }}
              placeholder="Enter username"
              className="bg-secondary/50 border-border rounded-xl"
            />
            <Button onClick={addFriend} className="gradient-primary rounded-xl shrink-0">
              <UserPlus size={16} />
            </Button>
          </div>
          {msg && <p className="text-xs mt-2 text-muted-foreground">{msg}</p>}
        </div>

        {/* Friend List */}
        <div>
          <h2 className="font-semibold text-foreground mb-3">Your Friends ({friendUsers.length})</h2>
          {friendUsers.length === 0 ? (
            <div className="glass rounded-xl p-6 text-center">
              <p className="text-3xl mb-2">👥</p>
              <p className="text-muted-foreground text-sm">No friends yet. Add some!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {friendUsers.map((f: any) => (
                <div key={f.id} className="glass rounded-xl p-3 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-accent flex items-center justify-center text-sm font-bold text-accent-foreground">
                    {f.username[0].toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">{f.username}</p>
                    <p className="text-[10px] text-muted-foreground">{f.points} pts · {f.currentStreak}🔥</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
