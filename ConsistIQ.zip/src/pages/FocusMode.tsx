import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { getTimeRemaining } from '@/lib/time';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { Task } from '@/types';

export default function FocusMode() {
  const { taskId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [remaining, setRemaining] = useState({ hours: 0, minutes: 0, seconds: 0, total: 0 });

  const task: Task | undefined = user?.history.flatMap(d => d.tasks).find(t => t.id === taskId);

  useEffect(() => {
    if (!task) return;
    const interval = setInterval(() => {
      setRemaining(getTimeRemaining(task.endTime, task.date));
    }, 1000);
    setRemaining(getTimeRemaining(task.endTime, task.date));
    return () => clearInterval(interval);
  }, [task]);

  if (!task) return <div className="min-h-screen gradient-bg flex items-center justify-center text-foreground">Task not found</div>;

  const totalDuration = (() => {
    const [sh, sm] = task.startTime.split(':').map(Number);
    const [eh, em] = task.endTime.split(':').map(Number);
    return ((eh * 60 + em) - (sh * 60 + sm)) * 60 * 1000;
  })();

  const progress = totalDuration > 0 ? Math.max(0, Math.min(100, ((totalDuration - remaining.total) / totalDuration) * 100)) : 0;
  const radius = 120;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="fixed inset-0 z-50 gradient-bg flex flex-col items-center justify-center p-6">
      <button onClick={() => navigate('/tasks')} className="absolute top-6 right-6 text-muted-foreground hover:text-foreground">
        <X size={24} />
      </button>

      <motion.p
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-muted-foreground text-sm mb-2 uppercase tracking-widest"
      >
        Focus Mode
      </motion.p>

      <motion.h1
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="text-2xl font-bold text-foreground mb-10 text-center"
      >
        {task.subject}
      </motion.h1>

      {/* Progress Ring */}
      <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="relative mb-10">
        <svg width="280" height="280" viewBox="0 0 280 280">
          <circle cx="140" cy="140" r={radius} fill="none" stroke="hsl(230 20% 16%)" strokeWidth="8" />
          <circle
            cx="140" cy="140" r={radius} fill="none"
            stroke="url(#grad)" strokeWidth="8" strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            transform="rotate(-90 140 140)"
            style={{ transition: 'stroke-dashoffset 1s linear' }}
          />
          <defs>
            <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="hsl(262 83% 58%)" />
              <stop offset="100%" stopColor="hsl(199 89% 48%)" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-4xl font-bold text-foreground tabular-nums">
            {String(remaining.hours).padStart(2, '0')}:{String(remaining.minutes).padStart(2, '0')}:{String(remaining.seconds).padStart(2, '0')}
          </span>
          <span className="text-xs text-muted-foreground mt-1">remaining</span>
        </div>
      </motion.div>

      <p className="text-muted-foreground text-sm">{Math.round(progress)}% complete</p>
    </div>
  );
}
