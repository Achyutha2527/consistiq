import { initializeApp, FirebaseApp } from 'firebase/app';
import { getMessaging, getToken, onMessage, Messaging } from 'firebase/messaging';

// Firebase config — these are publishable client-side keys.
// Replace with your own Firebase project config.
const firebaseConfig = {
  apiKey: "AIzaSyDEXAMPLE-REPLACE-ME",
  authDomain: "consistiq.firebaseapp.com",
  projectId: "consistiq",
  storageBucket: "consistiq.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef123456",
};

let app: FirebaseApp | null = null;
let messaging: Messaging | null = null;

function isSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window && 'serviceWorker' in navigator;
}

export function initFirebase(): FirebaseApp | null {
  if (app) return app;
  if (!isSupported()) return null;
  try {
    app = initializeApp(firebaseConfig);
    return app;
  } catch (e) {
    console.warn('Firebase init failed:', e);
    return null;
  }
}

export function getFirebaseMessaging(): Messaging | null {
  if (messaging) return messaging;
  const firebaseApp = initFirebase();
  if (!firebaseApp) return null;
  try {
    messaging = getMessaging(firebaseApp);
    return messaging;
  } catch (e) {
    console.warn('FCM init failed:', e);
    return null;
  }
}

export async function requestNotificationPermission(): Promise<string | null> {
  if (!isSupported()) return null;

  const permission = await Notification.requestPermission();
  if (permission !== 'granted') return null;

  const fcmMessaging = getFirebaseMessaging();
  if (!fcmMessaging) return null;

  try {
    // Send config to firebase-messaging-sw
    const registration = await navigator.serviceWorker.getRegistration('/firebase-messaging-sw.js');
    if (registration?.active) {
      registration.active.postMessage({ type: 'FIREBASE_CONFIG', config: firebaseConfig });
    }

    const token = await getToken(fcmMessaging, {
      vapidKey: 'REPLACE_WITH_YOUR_VAPID_KEY',
      serviceWorkerRegistration: registration,
    });
    return token;
  } catch (e) {
    console.warn('FCM token error:', e);
    return null;
  }
}

export function onForegroundMessage(callback: (payload: any) => void) {
  const fcmMessaging = getFirebaseMessaging();
  if (!fcmMessaging) return () => {};
  return onMessage(fcmMessaging, callback);
}
