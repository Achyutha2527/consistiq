import { UserData, Task, DayRecord, Badge } from '@/types';

const USERS_KEY = 'consistiq_users';
const SESSION_KEY = 'consistiq_session';

export function getAllUsers(): UserData[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  } catch { return []; }
}

function saveAllUsers(users: UserData[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function getUserByUsername(username: string): UserData | undefined {
  return getAllUsers().find(u => u.username.toLowerCase() === username.toLowerCase());
}

export function saveUser(user: UserData) {
  const users = getAllUsers();
  const idx = users.findIndex(u => u.id === user.id);
  if (idx >= 0) users[idx] = user;
  else users.push(user);
  saveAllUsers(users);
}

export function getSession(): string | null {
  return localStorage.getItem(SESSION_KEY);
}

export function setSession(userId: string) {
  localStorage.setItem(SESSION_KEY, userId);
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

export function getCurrentUser(): UserData | undefined {
  const id = getSession();
  if (!id) return undefined;
  return getAllUsers().find(u => u.id === id);
}

export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function generateId(): string {
  return crypto.randomUUID();
}

export function addTaskToDay(user: UserData, task: Task): UserData {
  const dayIdx = user.history.findIndex(d => d.date === task.date);
  if (dayIdx >= 0) {
    user.history[dayIdx].tasks.push(task);
  } else {
    user.history.push({ date: task.date, tasks: [task], completionPercentage: 0, points: 0, streak: 0 });
  }
  recalcDay(user, task.date);
  return { ...user };
}

export function updateTaskInUser(user: UserData, taskId: string, updates: Partial<Task>): UserData {
  for (const day of user.history) {
    const t = day.tasks.find(t => t.id === taskId);
    if (t) {
      Object.assign(t, updates);
      recalcDay(user, day.date);
      break;
    }
  }
  recalcStats(user);
  return { ...user };
}

function recalcDay(user: UserData, date: string) {
  const day = user.history.find(d => d.date === date);
  if (!day) return;
  const total = day.tasks.length;
  const completed = day.tasks.filter(t => t.status === 'completed').length;
  day.completionPercentage = total > 0 ? Math.round((completed / total) * 100) : 0;
  day.points = day.tasks.reduce((s, t) => s + t.points, 0);
}

export function recalcStats(user: UserData) {
  user.points = user.history.reduce((s, d) => s + d.points, 0);
  // Calculate streaks
  const sorted = [...user.history].sort((a, b) => b.date.localeCompare(a.date));
  let streak = 0;
  for (const day of sorted) {
    if (day.tasks.length > 0 && day.completionPercentage > 0) streak++;
    else break;
  }
  user.currentStreak = streak;
  if (streak > user.bestStreak) user.bestStreak = streak;
  // Badge
  if (user.bestStreak >= 30) user.badge = 'unstoppable';
  else if (user.bestStreak >= 7) user.badge = 'consistent';
  else user.badge = 'beginner';
}

export function deleteDayFromUser(user: UserData, date: string): UserData {
  user.history = user.history.filter(d => d.date !== date);
  recalcStats(user);
  return { ...user };
}

export function getTasksForDate(user: UserData, date: string): Task[] {
  return user.history.find(d => d.date === date)?.tasks || [];
}
