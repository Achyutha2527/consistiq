export function getISTNow(): Date {
  // Get current time in IST
  const now = new Date();
  const istString = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  return new Date(istString);
}

export function getISTDate(): string {
  return formatDateIST(getISTNow());
}

export function formatDateIST(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function isAfterEndTime(date: string, endTime: string): boolean {
  const now = getISTNow();
  const [h, m] = endTime.split(':').map(Number);
  const end = new Date(date);
  end.setHours(h, m, 0, 0);
  // Compare in IST
  const nowIST = getISTNow();
  return nowIST >= end;
}

export function formatTime(time: string): string {
  const [h, m] = time.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${String(m).padStart(2, '0')} ${ampm}`;
}

export function getTimeRemaining(endTime: string, date: string): { hours: number; minutes: number; seconds: number; total: number } {
  const now = getISTNow();
  const [h, m] = endTime.split(':').map(Number);
  const end = new Date(date);
  end.setHours(h, m, 0, 0);
  const total = Math.max(0, end.getTime() - now.getTime());
  return {
    total,
    hours: Math.floor(total / 3600000),
    minutes: Math.floor((total % 3600000) / 60000),
    seconds: Math.floor((total % 60000) / 1000),
  };
}
