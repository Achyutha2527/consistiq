import { Task } from '@/types';
import { getISTNow } from '@/lib/time';

const NOTIF_SETTINGS_KEY = 'consistiq_notif_settings';
const SCHEDULED_KEY = 'consistiq_scheduled_notifs';

interface NotifSettings {
  enabled: boolean;
  fcmToken: string | null;
}

export function getNotifSettings(): NotifSettings {
  try {
    const raw = localStorage.getItem(NOTIF_SETTINGS_KEY);
    if (raw) return JSON.parse(raw);
  } catch { }
  return { enabled: true, fcmToken: null };
}

export function saveNotifSettings(settings: NotifSettings) {
  localStorage.setItem(NOTIF_SETTINGS_KEY, JSON.stringify(settings));
}

// Track which notifications have been sent to avoid duplicates
function getScheduledIds(): Set<string> {
  try {
    return new Set(JSON.parse(localStorage.getItem(SCHEDULED_KEY) || '[]'));
  } catch { return new Set(); }
}

function markScheduled(id: string) {
  const ids = getScheduledIds();
  ids.add(id);
  // Keep only last 200 to prevent unbounded growth
  const arr = [...ids].slice(-200);
  localStorage.setItem(SCHEDULED_KEY, JSON.stringify(arr));
}

function wasScheduled(id: string): boolean {
  return getScheduledIds().has(id);
}

export function sendLocalNotification(title: string, body: string, url?: string) {
  const settings = getNotifSettings();
  if (!settings.enabled) return;
  if (!('Notification' in window) || Notification.permission !== 'granted') return;

  try {
    const registration = navigator.serviceWorker?.controller;
    if (navigator.serviceWorker?.ready) {
      navigator.serviceWorker.ready.then((reg) => {
        reg.showNotification(title, {
          body,
          icon: '/icons/icon-192x192.png',
          badge: '/icons/icon-192x192.png',
          data: { url: url || '/dashboard' },
          tag: `${title}-${Date.now()}`,
        });
      });
    } else {
      new Notification(title, { body, icon: '/icons/icon-192x192.png' });
    }
  } catch {
    try {
      new Notification(title, { body, icon: '/icons/icon-192x192.png' });
    } catch { }
  }
}

// Schedule task reminders
let reminderInterval: ReturnType<typeof setInterval> | null = null;

export function startTaskReminders(tasks: Task[]) {
  if (reminderInterval) clearInterval(reminderInterval);

  reminderInterval = setInterval(() => {
    const settings = getNotifSettings();
    if (!settings.enabled) return;

    const now = getISTNow();
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    for (const task of tasks) {
      if (task.status === 'completed' || task.status === 'missed') continue;

      const [startH, startM] = task.startTime.split(':').map(Number);
      const [endH, endM] = task.endTime.split(':').map(Number);
      const startMin = startH * 60 + startM;
      const endMin = endH * 60 + endM;

      // 5 minutes before start
      const beforeId = `before-${task.id}`;
      if (currentMinutes >= startMin - 5 && currentMinutes < startMin && !wasScheduled(beforeId)) {
        markScheduled(beforeId);
        sendLocalNotification(
          'Study session starting ⏳',
          `"${task.subject}" starts in 5 minutes`,
          '/tasks'
        );
      }

      // After end time if not completed
      const afterId = `after-${task.id}`;
      if (currentMinutes >= endMin + 1 && currentMinutes < endMin + 5 && !['completed', 'missed'].includes(task.status) && !wasScheduled(afterId)) {
        markScheduled(afterId);
        sendLocalNotification(
          'Unfinished task ⚠️',
          `"${task.subject}" ended — mark it now!`,
          '/tasks'
        );
      }
    }
  }, 30_000); // Check every 30 seconds
}

export function stopTaskReminders() {
  if (reminderInterval) {
    clearInterval(reminderInterval);
    reminderInterval = null;
  }
}

// Daily streak reminder
export function scheduleDailyReminder() {
  const settings = getNotifSettings();
  if (!settings.enabled) return;

  // Check every hour for daily reminder
  setInterval(() => {
    const now = getISTNow();
    const hour = now.getHours();
    const dailyId = `daily-${now.toISOString().split('T')[0]}`;

    // Send at 9 AM IST
    if (hour === 9 && !wasScheduled(dailyId)) {
      markScheduled(dailyId);
      sendLocalNotification(
        "Don't break your streak 🔥",
        'Plan your study session for today and stay consistent!',
        '/plan'
      );
    }

    // Inactivity reminder at 6 PM
    const eveningId = `evening-${now.toISOString().split('T')[0]}`;
    if (hour === 18 && !wasScheduled(eveningId)) {
      markScheduled(eveningId);
      sendLocalNotification(
        'Come back and stay consistent 💪',
        "You haven't completed all tasks today. Open ConsistIQ now!",
        '/tasks'
      );
    }
  }, 60_000 * 30); // Check every 30 min
}
