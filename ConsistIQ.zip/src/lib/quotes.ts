const loginQuotes = [
  "Discipline is the bridge between goals and accomplishment.",
  "The secret of getting ahead is getting started.",
  "Success is the sum of small efforts repeated day in and day out.",
  "Your future is created by what you do today, not tomorrow.",
  "Consistency is what transforms average into excellence.",
  "The only way to do great work is to love what you do.",
  "Don't watch the clock; do what it does. Keep going.",
];

const successQuotes = [
  "You did it! Every completed task is a brick in your success.",
  "Champions keep going when they have nothing left.",
  "Another task crushed. You're unstoppable!",
  "Hard work beats talent when talent doesn't work hard.",
  "One step closer to greatness. Keep pushing!",
  "Excellence is not a skill. It's an attitude.",
];

const missedQuotes = [
  "Fall seven times, stand up eight.",
  "It's not about perfection. It's about progress.",
  "Every setback is a setup for a comeback.",
  "You haven't failed until you stop trying.",
  "Tomorrow is a new chance to be better.",
  "The comeback is always stronger than the setback.",
];

function random<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function getLoginQuote() { return random(loginQuotes); }
export function getSuccessQuote() { return random(successQuotes); }
export function getMissedQuote() { return random(missedQuotes); }
