export type TaskStatus = 'upcoming' | 'in-progress' | 'pending' | 'completed' | 'missed';

export interface Task {
  id: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  subject: string;
  status: TaskStatus;
  reason?: string;
  points: number;
  lockedAt?: string;
}

export interface DayRecord {
  date: string;
  tasks: Task[];
  completionPercentage: number;
  points: number;
  streak: number;
}

export interface UserData {
  id: string;
  username: string;
  passwordHash: string;
  createdAt: string;
  points: number;
  currentStreak: number;
  bestStreak: number;
  badge: Badge;
  history: DayRecord[];
  friends: string[];
  friendCodes: string[];
}

export type Badge = 'beginner' | 'consistent' | 'unstoppable';

export interface LeaderboardEntry {
  username: string;
  points: number;
  streak: number;
  completionPct: number;
  isSimulated?: boolean;
}
