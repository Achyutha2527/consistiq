import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserData } from '@/types';
import { getCurrentUser, saveUser, setSession, clearSession, getUserByUsername, hashPassword, generateId, recalcStats } from '@/lib/storage';

interface AuthContextType {
  user: UserData | null;
  login: (username: string, password: string) => Promise<boolean>;
  signup: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUser: (user: UserData) => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const u = getCurrentUser();
    if (u) setUser(u);
    setLoading(false);
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    const u = getUserByUsername(username);
    if (!u) return false;
    const hash = await hashPassword(password);
    if (u.passwordHash !== hash) return false;
    setSession(u.id);
    setUser(u);
    return true;
  }, []);

  const signup = useCallback(async (username: string, password: string) => {
    if (getUserByUsername(username)) return { success: false, error: 'Username already taken' };
    const hash = await hashPassword(password);
    const newUser: UserData = {
      id: generateId(),
      username,
      passwordHash: hash,
      createdAt: new Date().toISOString(),
      points: 0,
      currentStreak: 0,
      bestStreak: 0,
      badge: 'beginner',
      history: [],
      friends: [],
      friendCodes: [generateId().slice(0, 8).toUpperCase()],
    };
    saveUser(newUser);
    setSession(newUser.id);
    setUser(newUser);
    return { success: true };
  }, []);

  const logout = useCallback(() => {
    clearSession();
    setUser(null);
  }, []);

  const updateUser = useCallback((u: UserData) => {
    recalcStats(u);
    saveUser(u);
    setUser({ ...u });
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateUser, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
}
